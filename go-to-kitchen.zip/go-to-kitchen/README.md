# اذهبي إلى المطبخ 🌍🍳

موقع Static ترفيهي يعرض عبارة «اذهبي إلى المطبخ» بـ50 لغة مختلفة، مع 50 مفهوم ميم مولّد داخل الواجهة باستخدام HTML/CSS/Emoji، دون Backend أو مكتبات JavaScript مطلوبة.

## المزايا

- Vanilla HTML/CSS/JavaScript.
- 50 لغة محفوظة في Array واحدة داخل `script.js`.
- بطاقات مولدة تلقائيًا من البيانات.
- Meme Viewer داخل Modal بدون روابط خارجية.
- Meme concept مختلف لكل لغة.
- بحث باسم اللغة بالعربية/الإنجليزية أو بجزء من العبارة.
- فلترة: الكل، الأبجدية، الرقم، المفضلة، عشوائي.
- Random.
- Next / Previous مع دوران من 50 إلى 1.
- نسخ العبارة عبر Clipboard مع fallback.
- مشاركة عبر Web Share API مع fallback لنسخ الرابط.
- Dark/Light Mode محفوظ في `localStorage`.
- حفظ اللغات التي شاهدها المستخدم وآخر لغة.
- RTL/LTR حسب اللغة.
- Keyboard navigation وESC وARIA وfocus management.
- Responsive Mobile First.
- يعمل محليًا بفتح `index.html`، ويصلح لـGitHub Pages.
- لا توجد صور خارجية ضرورية؛ لذلك لا يتعطل الموقع بسبب CDN أو خدمة صور.
- دعم `prefers-reduced-motion`.
- GitHub Actions للنشر التلقائي.

> ملاحظة: تحميل Google Fonts في `style.css` اختياري فقط لتحسين الخطوط. إذا انقطع الإنترنت أو فشل الـCDN، تعمل الصفحة باستخدام fallback fonts ولا تتوقف الوظائف الأساسية.

## هيكل المشروع

```text
/
├── index.html
├── style.css
├── script.js
├── README.md
├── .nojekyll
├── assets/
│   ├── memes/
│   ├── flags/
│   └── icons/
└── .github/
    └── workflows/
        └── deploy.yml
```

المجلدات `assets` موجودة كاحتياط للتوسعة المستقبلية، لكن النسخة الحالية لا تعتمد على ملفات صور خارجية.

## تشغيل محلي

### الطريقة الأبسط

افتح `index.html` مباشرة في Chrome أو Firefox أو Edge أو Safari.

### باستخدام خادم محلي اختياري

إذا كان Python مثبتًا:

```bash
python -m http.server 8000
```

ثم افتح:

```text
http://localhost:8000
```

## النشر على GitHub Pages

1. أنشئ Repository جديدًا على GitHub، مثل:
   `go-to-kitchen`
2. انسخ جميع ملفات المشروع إلى Repository.
3. نفّذ:

```bash
git init
git add .
git commit -m "Initial release"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

4. افتح Repository على GitHub.
5. ادخل إلى **Settings → Pages**.
6. في **Build and deployment** اختر **GitHub Actions**.
7. سيقوم `deploy.yml` بالنشر تلقائيًا عند كل Push إلى `main`.
8. بعد اكتمال الـWorkflow سيكون الرابط المتوقع:

```text
https://USERNAME.github.io/REPOSITORY/
```

استبدل `USERNAME` باسم حساب GitHub الحقيقي و`REPOSITORY` باسم المستودع.

## النشر اليدوي البديل

إذا لم ترد استخدام GitHub Actions، يمكن اختيار:

- Branch: `main`
- Folder: `/ (root)`

من إعدادات GitHub Pages عندما تكون هذه الخيارات متاحة لحالة المستودع.

## التخصيص

كل محتوى اللغات والميمز موجود في بداية `script.js` داخل:

```js
const languages = [...]
```

كل عنصر يحتوي على:

```js
{
  id,
  name,
  arabicName,
  flag,
  text,
  memeTitle,
  memeEmoji,
  memeCaption,
  direction,
  theme
}
```

لتغيير ميم لغة، عدّل `memeTitle` أو `memeEmoji` أو `memeCaption` أو `theme`.

## اختبار سريع قبل النشر

- افتح الصفحة.
- جرّب البحث بـ`Japanese` ثم `اليابانية` ثم `キッチン`.
- افتح أي ميم وجرب السابق/التالي.
- جرّب النسخ والمشاركة.
- بدّل Dark/Light ثم أعد تحميل الصفحة.
- أضف لغات إلى المفضلة وجرب فلتر ⭐.
- اضغط شعار الموقع 5 مرات لاختبار Easter Egg.
- على الهاتف جرّب فتح وإغلاق Modal والتنقل بين اللغات.

## الترخيص والمحتوى

الميمز في النسخة الأساسية ليست صورًا مقتبسة من أعمال محمية؛ هي Concepts مرئية مبنية من Emoji/CSS/HTML. إذا أضفت صورًا خارجية، استخدم فقط صورًا تملك حق استخدامها أو صورًا بترخيص يسمح بإعادة الاستخدام.
