'use strict';

const languages = [
  [1,'English','الإنجليزية','🇬🇧','Go to the kitchen','The Mission','🫡🍳','When the mission is clear...','ltr',1],
  [2,'French','الفرنسية','🇫🇷','Va à la cuisine','Le départ dramatique','🥖🚶‍♀️','Direction la cuisine. Sans négociation.','ltr',2],
  [3,'Spanish','الإسبانية','🇪🇸','Ve a la cocina','La orden','💃🍳','Cuando la cocina te llama...','ltr',3],
  [4,'German','الألمانية','🇩🇪','Geh in die Küche','Very Serious Business','🫡🥨','Ordnung muss sein. Auch in der Küche.','ltr',1],
  [5,'Italian','الإيطالية','🇮🇹','Vai in cucina','Mamma Mia!','🤌🍝','The hands are talking. The kitchen awaits.','ltr',4],
  [6,'Portuguese','البرتغالية','🇵🇹','Vá para a cozinha','Operation Kitchen','😎🍳','A missão começou.','ltr',5],
  [7,'Russian','الروسية','🇷🇺','Иди на кухню','The Command','🪆🚶','No questions. Just kitchen.','ltr',6],
  [8,'Chinese (Simplified)','الصينية (المبسطة)','🇨🇳','去厨房','Kitchen Quest','🐼🥢','The panda has received the message.','ltr',7],
  [9,'Japanese','اليابانية','🇯🇵','キッチンに行ってください','Anime Kitchen Arc','🍙✨🚶‍♀️','The next episode begins... in the kitchen.','ltr',8],
  [10,'Korean','الكورية','🇰🇷','부엌으로 가세요','K-Drama Moment','🎬😭🍳','*dramatic music intensifies*','ltr',5],
  [11,'Arabic','العربية','🇸🇦','اذهبي إلى المطبخ','الاستسلام الأخير','😂🙋‍♀️🍳','عندما تسمعين الجملة وتعرفين أن النقاش انتهى.','rtl',2],
  [12,'Turkish','التركية','🇹🇷','Mutfakka git','Kitchen Mission','🧿🚶‍♀️🍳','Görev belli.','ltr',3],
  [13,'Hindi','الهندية','🇮🇳','रसोई में जाओ','Bollywood Kitchen','🎬💃🍛','Every kitchen deserves a dramatic entrance.','ltr',4],
  [14,'Persian','الفارسية','🇮🇷','برو به آشپزخانه','The Kitchen Call','🍵🚶‍♀️','The tea can wait. The kitchen cannot.','rtl',6],
  [15,'Swedish','السويدية','🇸🇪','Gå till köket','Nordic Mission','🧊🫡🍳','Calm. Precise. Kitchen.','ltr',7],
  [16,'Danish','الدنماركية','🇩🇰','Gå til køkkenet','Hygge Emergency','🧸🍳🚶','Even hygge has chores.','ltr',8],
  [17,'Norwegian','النرويجية','🇳🇴','Gå til kjøkkenet','Fjord to Kitchen','⛰️🚶‍♀️🍳','A long journey for a short sentence.','ltr',1],
  [18,'Finnish','الفنلندية','🇫🇮','Mene keittiöön','The Quiet Order','😐🍳','No drama. Just execute.','ltr',2],
  [19,'Polish','البولندية','🇵🇱','Idź do kuchni','Kitchen Alert','🚨🥟🍳','This is not a drill.','ltr',3],
  [20,'Czech','التشيكية','🇨🇿','Jdi do kuchyně','Mission Dumpling','🥟🫡','The dumplings are waiting.','ltr',4],
  [21,'Hungarian','المجرية','🇭🇺','Menj a konyhába','Paprika Protocol','🌶️🍳','Activate kitchen mode.','ltr',5],
  [22,'Romanian','الرومانية','🇷🇴','Mergi în bucătărie','Kitchen Summoning','🔮🍳','The kitchen has summoned you.','ltr',6],
  [23,'Greek','اليونانية','🇬🇷','Πήγαινε στην κουζίνα','Olympus Kitchen','🏛️🍳⚡','A heroic quest begins.','ltr',7],
  [24,'Dutch','الهولندية','🇳🇱','Ga naar de keuken','Direct Route','🚲🍳','No detours. Kitchen only.','ltr',8],
  [25,'Bulgarian','البلغارية','🇧🇬','Отиди в кухнята','Kitchen Patrol','🫡🍳','The patrol has a destination.','ltr',1],
  [26,'Serbian','الصربية','🇷🇸','Idi u kuhinju','Kitchen Commander','🪖🍳','Orders received.','ltr',2],
  [27,'Croatian','الكرواتية','🇭🇷','Idi u kuhinju','Adriatic Kitchen','🌊🍳🚶','From the coast to the kitchen.','ltr',3],
  [28,'Slovenian','السلوفينية','🇸🇮','Pojdi v kuhinjo','Tiny Mission','🗺️🍳','Small country, big kitchen mission.','ltr',4],
  [29,'Ukrainian','الأوكرانية','🇺🇦','Іди на кухню','Kitchen Courage','💙💛🍳','Brave steps toward dinner.','ltr',5],
  [30,'Hebrew','العبرية','🇮🇱','לך למטבח','Kitchen Signal','📡🍳','Signal received.','rtl',6],
  [31,'Swiss German','السويسرية (الألمانية)','🇨🇭','Geh in die Küche','Swiss Precision','⌚🍳','Precisely on schedule.','ltr',7],
  [32,'Swiss French','السويسرية (الفرنسية)','🇨🇭','Va à la cuisine','Swiss Drama','🧀🥖🍳','A refined route to the kitchen.','ltr',8],
  [33,'Swiss Italian','السويسرية (الإيطالية)','🇨🇭','Vai in cucina','Alpine Pasta','🏔️🍝🍳','The Alps are watching.','ltr',1],
  [34,'Indonesian','الإندونيسية','🇮🇩','Pergi ke dapur','Tropical Kitchen','🌴🍳🚶','Straight to the kitchen.','ltr',2],
  [35,'Vietnamese','الفيتنامية','🇻🇳','Đi vào bếp','Kitchen Ride','🛵🍜🍳','Fast route to the kitchen.','ltr',3],
  [36,'Thai','التايلاندية','🇹🇭','ไปที่ครัว','Spicy Mission','🌶️🍜🔥','Warning: kitchen may be spicy.','ltr',4],
  [37,'Malay','الماليزية','🇲🇾','Pergi ke dapur','Kitchen Explorer','🧭🍳','Adventure starts at the stove.','ltr',5],
  [38,'Filipino','الفلبينية','🇵🇭','Pumunta ka sa kusina','Kitchen Fiesta','🎉🍳💃','The kitchen party is calling.','ltr',6],
  [39,'Swahili','السواحيلية','🇹🇿','Nenda jikoni','Kitchen Safari','🦁🍳🚶','Next stop: the kitchen.','ltr',7],
  [40,'Afrikaans','الأفريكانية','🇿🇦','Gaan na die kombuis','Kitchen Express','🚂🍳','All aboard for the kitchen.','ltr',8],
  [41,'Nepali','النيبالية','🇳🇵','भान्सामा जाओ','Mountain Kitchen','🏔️🍳','The kitchen is down this way.','ltr',1],
  [42,'Bengali','البنغالية','🇧🇩','রান্নাঘরে যাও','Kitchen Rhythm','🥁🍳','A rhythmic journey to dinner.','ltr',2],
  [43,'Urdu','الأردية','🇵🇰','کچن میں جاؤ','Kitchen Drama','🎭🍳','And the drama begins.','rtl',3],
  [44,'Kurdish','الكردية','🟩','Bê kuçê re','Kitchen Quest','🧿🍳🧭','Destination: kitchen.','ltr',4],
  [45,'Albanian','الألبانية','🇦🇱','Shko në kuzhinë','Kitchen Eagle','🦅🍳','Eyes on the kitchen.','ltr',5],
  [46,'Lithuanian','اللتوانية','🇱🇹','Eik į virtuvę','Baltic Mission','🌊🍳','A Baltic trip to the stove.','ltr',6],
  [47,'Estonian','الإستونية','🇪🇪','Mine kööki','Digital Kitchen','💻🍳','Loading kitchen.exe...','ltr',7],
  [48,'Latvian','اللاتفية','🇱🇻','Ej uz virtuvi','Kitchen Compass','🧭🍳','The compass points to dinner.','ltr',8],
  [49,'Icelandic','الأيسلندية','🇮🇸','Farðu í eldhúsið','Volcanic Kitchen','🌋🍳','A hot route to the kitchen.','ltr',1],
  [50,'Maltese','المالطية','🇲🇹','Mur fil-kċina','Island Kitchen','🏝️🍳🚶','Island mode: kitchen.','ltr',2]
].map(([id,name,arabicName,flag,text,memeTitle,memeEmoji,memeCaption,direction,theme]) => ({id,name,arabicName,flag,text,memeTitle,memeEmoji,memeCaption,direction,theme}));

const $ = (id) => document.getElementById(id);
const state = { index: 0, filtered: [...languages], favorites: new Set(JSON.parse(localStorage.getItem('kitchenFavorites') || '[]')), seen: new Set(JSON.parse(localStorage.getItem('kitchenSeen') || '[]')), last: Number(localStorage.getItem('kitchenLast') || 0), theme: localStorage.getItem('kitchenTheme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'), logoClicks: 0, modalOpen: false, lastFocus: null };

function saveState(){localStorage.setItem('kitchenFavorites', JSON.stringify([...state.favorites]));localStorage.setItem('kitchenSeen', JSON.stringify([...state.seen]));localStorage.setItem('kitchenLast', String(state.last));}
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2200);}
function setTheme(theme){state.theme=theme;document.body.classList.toggle('dark',theme==='dark');$('themeBtn').textContent=theme==='dark'?'☀️':'🌙';$('themeBtn').setAttribute('aria-label',theme==='dark'?'تبديل الوضع الفاتح':'تبديل الوضع الداكن');$('themeBtn').setAttribute('aria-pressed',String(theme==='dark'));localStorage.setItem('kitchenTheme',theme);}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function cardTemplate(item){const fav=state.favorites.has(item.id);return `<article class="language-card" data-id="${item.id}" tabindex="0"><div class="card-top"><span class="card-number">${String(item.id).padStart(2,'0')}</span><span class="flag" aria-hidden="true">${item.flag}</span><button class="fav-btn ${fav?'active':''}" type="button" data-fav="${item.id}" aria-label="${fav?'إزالة':'إضافة'} ${escapeHtml(item.name)} ${fav?'من':'إلى'} المفضلة">${fav?'★':'☆'}</button></div><div class="language-name">${escapeHtml(item.name)}</div><div class="language-arabic">${escapeHtml(item.arabicName)}</div><div class="language-text" dir="${item.direction}">${escapeHtml(item.text)}</div><button class="btn btn-primary" type="button" data-open="${item.id}">شاهد الميم 😂</button></article>`;}
function render(){const grid=$('languages');grid.innerHTML=state.filtered.length?state.filtered.map(cardTemplate).join(''):`<div class="empty"><div style="font-size:3rem">🧐</div><strong>لم نجد لغة بهذه الكلمات.</strong><br>جرّبي اسمًا آخر أو أعيدي الفلتر إلى «جميع اللغات».</div>`;$('resultsCount').textContent=`${state.filtered.length} ${state.filtered.length===1?'لغة':'لغات'}`;$('emptyHint').hidden=state.filtered.length>0;}
function normalize(s){return s.toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');}
function applyFilters(){const q=normalize($('searchInput').value.trim());let list=languages.filter(x=>!q||[x.name,x.arabicName,x.text].some(v=>normalize(v).includes(q)));const mode=$('filterSelect').value;if(mode==='favorites')list=list.filter(x=>state.favorites.has(x.id));if(mode==='alpha')list.sort((a,b)=>a.name.localeCompare(b.name));if(mode==='number')list.sort((a,b)=>a.id-b.id);if(mode==='random')list.sort(()=>Math.random()-.5);state.filtered=list;render();}
function markSeen(id){state.seen.add(id);state.last=id;saveState();updateProgress();}
function updateProgress(){const count=state.seen.size;$('progressText').textContent=`${state.last?String(state.last).padStart(2,'0'):'00'} / 50`;$('seenText').textContent=`لقد شاهدت ${count} من 50 لغة 😂`;$('progressBar').style.width=`${Math.min(100,count*2)}%`;if(count===50)$('finishSection').hidden=false;}
function openModal(id){const item=languages.find(x=>x.id===id);if(!item)return;state.index=languages.findIndex(x=>x.id===id);state.lastFocus=document.activeElement;state.modalOpen=true;$('memeModal').classList.add('open');$('memeModal').setAttribute('aria-hidden','false');document.body.style.overflow='hidden';markSeen(id);updateModal(item);requestAnimationFrame(()=>$('closeModal').focus());}
function updateModal(item){$('modalNumber').textContent=`${String(item.id).padStart(2,'0')} / 50`;$('modalLanguage').textContent=`${item.flag} ${item.name}`;$('modalText').textContent=item.text;$('modalText').dir=item.direction;$('modalTitle').textContent=item.name;$('modalMemeTitle').textContent=item.memeTitle;$('modalEmoji').textContent=item.memeEmoji;$('modalCaption').textContent=item.memeCaption;$('memeStage').className=`meme-stage theme-${item.theme}`;$('memeArt').textContent=item.memeEmoji;}
function closeModal(){if(!state.modalOpen)return;state.modalOpen=false;$('memeModal').classList.remove('open');$('memeModal').setAttribute('aria-hidden','true');document.body.style.overflow='';if(state.lastFocus&&typeof state.lastFocus.focus==='function')state.lastFocus.focus();}
function next(delta=1){state.index=(state.index+delta+languages.length)%languages.length;openModal(languages[state.index].id);}
async function copyText(){const item=languages[state.index];try{await navigator.clipboard.writeText(item.text);toast('تم النسخ! ✓')}catch{const ta=document.createElement('textarea');ta.value=item.text;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();toast('تم النسخ! ✓')}}
async function shareSite(){const item=languages[state.index];const data={title:'اذهبي إلى المطبخ - 50 لغة',text:`${item.flag} ${item.text}\nاذهبي إلى المطبخ 😂`,url:location.href};try{if(navigator.share){await navigator.share(data);toast('تم فتح المشاركة 🔗')}else{await navigator.clipboard.writeText(location.href);toast('تم نسخ رابط المشاركة 🔗')}}catch(e){if(e&&e.name!=='AbortError')toast('تعذرت المشاركة، حاولي مرة أخرى')}}
function randomOpen(){const item=languages[Math.floor(Math.random()*languages.length)];openModal(item.id);}
function scrollToLanguages(){document.querySelector('.explorer').scrollIntoView({behavior:'smooth'});setTimeout(()=>$('languages').focus(),500);}

$('year').textContent=new Date().getFullYear();setTheme(state.theme);render();updateProgress();
$('themeBtn').addEventListener('click',()=>setTheme(state.theme==='dark'?'light':'dark'));
$('startBtn').addEventListener('click',scrollToLanguages);$('journeyBtn').addEventListener('click',scrollToLanguages);$('randomBtn').addEventListener('click',randomOpen);$('finishRandomBtn').addEventListener('click',randomOpen);
$('searchInput').addEventListener('input',applyFilters);$('filterSelect').addEventListener('change',applyFilters);
$('languages').addEventListener('click',e=>{const fav=e.target.closest('[data-fav]');if(fav){const id=Number(fav.dataset.fav);state.favorites.has(id)?state.favorites.delete(id):state.favorites.add(id);saveState();applyFilters();return}const open=e.target.closest('[data-open]');if(open)openModal(Number(open.dataset.open));});
$('languages').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.classList.contains('language-card'))openModal(Number(e.target.dataset.id));});
$('closeModal').addEventListener('click',closeModal);$('memeModal').addEventListener('click',e=>{if(e.target.dataset.closeModal==='true')closeModal()});$('prevBtn').addEventListener('click',()=>next(-1));$('nextBtn').addEventListener('click',()=>next(1));$('copyBtn').addEventListener('click',copyText);$('shareBtn').addEventListener('click',shareSite);
$('restartBtn').addEventListener('click',()=>{state.seen.clear();state.last=0;saveState();updateProgress();scrollToLanguages();});$('finishShareBtn').addEventListener('click',async()=>{try{await navigator.share?.({title:'اذهبي إلى المطبخ - 50 لغة',text:'نفس الجملة، 50 لغة، و50 طريقة مختلفة 😂🌍',url:location.href});if(!navigator.share){await navigator.clipboard.writeText(location.href);toast('تم نسخ رابط المشاركة 🔗')}}catch(e){if(e.name!=='AbortError')toast('تعذرت المشاركة')}});
$('brandButton').addEventListener('click',()=>{state.logoClicks++;if(state.logoClicks===5){toast('هل تريدين الذهاب إلى المطبخ أم أرسلها لك بـ50 لغة أخرى؟ 😂');state.logoClicks=0}});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();if(state.modalOpen&&e.key==='ArrowRight')next(1);if(state.modalOpen&&e.key==='ArrowLeft')next(-1);});
window.addEventListener('storage',()=>{setTheme(localStorage.getItem('kitchenTheme')||'light')});
